<?php
$stripe_secret_key = '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';
$session_id = $_GET['session_id'] ?? '';

$email = '';
if ($session_id) {
    // Verify session and get email
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/checkout/sessions/' . $session_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $stripe_secret_key . ':');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    $session = json_decode($result, true);
    if (isset($session['customer_details']['email'])) {
        $email = $session['customer_details']['email'];

        // Save to "database" (JSON file)
        $file = 'paid_users.json';
        $paid_users = json_decode(file_get_contents($file), true);
        if (!in_array($email, $paid_users)) {
            $paid_users[] = $email;
            file_put_contents($file, json_encode($paid_users));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - TradeCalc</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #121212; color: white; font-family: 'Inter', sans-serif; text-align: center; }
        .container { background-color: #1A1A1A; padding: 40px; border-radius: 16px; border: 1px solid #333; max-width: 400px; }
        .success-icon { font-size: 64px; color: #FFC107; margin-bottom: 20px; }
        h1 { margin-bottom: 10px; }
        p { color: #A0A0A0; margin-bottom: 30px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✓</div>
        <h1>Payment Successful!</h1>
        <p>Your calculator has been unlocked for <strong><?php echo htmlspecialchars($email); ?></strong>. Redirecting...</p>
    </div>

    <script>
        // Set payment status locally
        localStorage.setItem('tradecalc_paid', 'true');
        localStorage.setItem('tradecalc_email', '<?php echo $email; ?>');
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);
    </script>
</body>
</html>
