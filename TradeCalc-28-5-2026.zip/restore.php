<?php
header('Content-Type: application/json');

$email = $_POST['email'] ?? '';
$stripe_secret_key = 'sk_test_51OFBcaGdc1xOCo47tFlDXhWTpP68zoBqUbVtQl3G7fwgwS61QrQNodrqfAEfXeRR5xj6rTJhbLaXHHHLHH6AHuuv00BrYdbPDV';

if (!$email) {
    echo json_encode(['success' => false, 'error' => 'Email is required']);
    exit;
}

// 1. First, check our local cache (paid_users.json) for speed
$file = 'paid_users.json';
$paid_users = json_decode(file_get_contents($file), true);
if (in_array(strtolower(trim($email)), array_map('strtolower', $paid_users))) {
    echo json_encode(['success' => true]);
    exit;
}

// 2. If not in local cache, verify directly with Stripe API
// We search for successful charges with this email
$query = "customer_email:'" . trim($email) . "' AND status:'succeeded'";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/charges/search?query=' . urlencode($query));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERPWD, $stripe_secret_key . ':');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$response = json_decode($result, true);

if ($http_code === 200 && !empty($response['data'])) {
    // Payment found in Stripe! 
    // Update local cache so we don't have to hit Stripe API next time
    if (!in_array($email, $paid_users)) {
        $paid_users[] = $email;
        file_put_contents($file, json_encode($paid_users));
    }
    echo json_encode(['success' => true]);
} else {
    // Either Stripe API failed or no successful charge found
    echo json_encode(['success' => false, 'error' => "We couldn't find a record of purchase for this email. Please ensure you are using the same email address used during checkout."]);
}
?>
