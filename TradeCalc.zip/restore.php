<?php
header('Content-Type: application/json');

$email = $_POST['email'] ?? '';

if (!$email) {
    echo json_encode(['success' => false, 'error' => 'Email is required']);
    exit;
}

$file = 'paid_users.json';
$paid_users = json_decode(file_get_contents($file), true);

if (in_array(strtolower(trim($email)), array_map('strtolower', $paid_users))) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Email not found in our records.']);
}
?>
