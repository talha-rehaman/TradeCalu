<?php
// STRIPE_SECRET_KEY - Provided by user
$stripe_secret_key = 'sk_test_51OFBcaGdc1xOCo47tFlDXhWTpP68zoBqUbVtQl3G7fwgwS61QrQNodrqfAEfXeRR5xj6rTJhbLaXHHHLHH6AHuuv00BrYdbPDV';

// Get the protocol and host for the success/cancel URLs
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$base_url = $protocol . "://" . $host . dirname($_SERVER['PHP_SELF']);

// Create a Checkout Session using cURL (No SDK required)
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/checkout/sessions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'payment_method_types[]' => 'card',
    'line_items[0][price_data][currency]' => 'gbp',
    'line_items[0][price_data][product_data][name]' => 'TradeCalc Access',
    'line_items[0][price_data][unit_amount]' => 1000, // £10.00
    'line_items[0][quantity]' => 1,
    'mode' => 'payment',
    'success_url' => $base_url . '/success.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => $base_url . '/index.html',
]));
curl_setopt($ch, CURLOPT_USERPWD, $stripe_secret_key . ':');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For local development on XAMPP
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); 
curl_setopt($ch, CURLOPT_TIMEOUT, 30); // 30 seconds timeout

$result = curl_exec($ch);
if ($result === false) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'cURL Error: ' . curl_error($ch)]);
    exit;
}
curl_close($ch);

$session = json_decode($result, true);

if (isset($session['id'])) {
    // Return the session ID to the frontend
    header('Content-Type: application/json');
    echo json_encode(['id' => $session['id']]);
} else {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => $session]);
}
?>
