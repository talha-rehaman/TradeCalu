<?php
$stripe_secret_key = 'sk_test_51OFBcaGdc1xOCo47tFlDXhWTpP68zoBqUbVtQl3G7fwgwS61QrQNodrqfAEfXeRR5xj6rTJhbLaXHHHLHH6AHuuv00BrYdbPDV';
$session_id = $_GET['session_id'] ?? '';

$email = '';
if ($session_id) {
    // Verify session and get email, name, and payment details
    $ch = curl_init();
    // Expand payment_intent and payment_method to get card details
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/checkout/sessions/' . $session_id . '?expand[]=payment_intent.payment_method');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $stripe_secret_key . ':');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    $session = json_decode($result, true);
    if (isset($session['customer_details']['email'])) {
        $email = $session['customer_details']['email'];
        $name = $session['customer_details']['name'] ?? 'N/A';
        $ip = $_SERVER['REMOTE_ADDR'];
        $last4 = $session['payment_intent']['payment_method']['card']['last4'] ?? 'N/A';

        // Save to "database" (JSON file)
        $file = 'paid_users.json';
        $data = json_decode(file_get_contents($file), true);
        
        // Handle migration from old array format to new object format if necessary
        if (!empty($data) && is_string($data[0])) {
            $new_data = [];
            foreach ($data as $old_email) {
                $new_data[] = [
                    'email' => $old_email,
                    'name' => 'Legacy User',
                    'ip' => 'Unknown',
                    'last4' => 'Unknown'
                ];
            }
            $data = $new_data;
        }

        // Check if user already exists
        $exists = false;
        foreach ($data as $user) {
            if (isset($user['email']) && $user['email'] === $email) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $data[] = [
                'email' => $email,
                'name' => $name,
                'ip' => $ip,
                'last4' => $last4,
                'date' => date('Y-m-d H:i:s')
            ];
            file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - TradeCalc</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #121212; color: white; font-family: 'Inter', sans-serif; text-align: center; }
        .container { background-color: #1A1A1A; padding: 40px; border-radius: 16px; border: 1px solid #333; max-width: 400px; }
        .success-icon { font-size: 64px; color: #FFC107; margin-bottom: 20px; }
        h1 { margin-bottom: 10px; }
        p { color: #A0A0A0; margin-bottom: 30px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✓</div>
        <h1>Payment Successful!</h1>
        <p>Your calculator has been unlocked for <strong><?php echo htmlspecialchars($email); ?></strong>. Redirecting...</p>
    </div>

    <script>
        // Set payment status locally
        localStorage.setItem('tradecalc_paid', 'true');
        localStorage.setItem('tradecalc_email', '<?php echo $email; ?>');
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);
    </script>
</body>
</html>
