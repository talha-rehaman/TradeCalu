<?php
header('Content-Type: application/json');

$email = $_POST['email'] ?? '';
$last4_input = $_POST['last4'] ?? '';
$current_ip = $_SERVER['REMOTE_ADDR'];
$stripe_secret_key = 'sk_test_51OFBcaGdc1xOCo47tFlDXhWTpP68zoBqUbVtQl3G7fwgwS61QrQNodrqfAEfXeRR5xj6rTJhbLaXHHHLHH6AHuuv00BrYdbPDV';

if (!$email) {
    echo json_encode(['success' => false, 'error' => 'Email is required']);
    exit;
}

// 1. First, check our local cache (paid_users.json)
$file = 'paid_users.json';
$data = json_decode(file_get_contents($file), true);

// Handle migration/normalization
if (!empty($data) && is_string($data[0])) {
    $new_data = [];
    foreach ($data as $old_email) {
        $new_data[] = ['email' => $old_email, 'name' => 'Legacy User', 'ip' => 'Unknown', 'last4' => 'Unknown'];
    }
    $data = $new_data;
}

$found_user = null;
foreach ($data as $user) {
    if (isset($user['email']) && strtolower(trim($user['email'])) === strtolower(trim($email))) {
        $found_user = $user;
        break;
    }
}

if ($found_user) {
    // If we have card digits recorded, we MUST match them
    if ($found_user['last4'] !== 'Unknown') {
        if (trim($last4_input) !== trim($found_user['last4'])) {
            echo json_encode(['success' => false, 'error' => 'Incorrect card digits provided.']);
            exit;
        }
        
        // Also update IP if it changed
        if ($found_user['ip'] !== $current_ip) {
            foreach ($data as $key => $user) {
                if ($user['email'] === $found_user['email']) {
                    $data[$key]['ip'] = $current_ip;
                    break;
                }
            }
            file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
        }
        
        echo json_encode(['success' => true]);
        exit;
    }
    // If last4 is 'Unknown', we fall through to the Stripe check below to fetch and verify it
}

// 2. If not in local cache, verify directly with Stripe API
$query = "customer_email:'" . trim($email) . "' AND status:'succeeded'";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/charges/search?query=' . urlencode($query));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERPWD, $stripe_secret_key . ':');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$response = json_decode($result, true);

if ($http_code === 200 && !empty($response['data'])) {
    // Payment found in Stripe!
    $charge = $response['data'][0];
    $stripe_last4 = $charge['payment_method_details']['card']['last4'] ?? 'Unknown';

    // VERIFICATION: Check provided digits against Stripe records
    if ($stripe_last4 !== 'Unknown' && trim($last4_input) !== trim($stripe_last4)) {
        echo json_encode(['success' => false, 'error' => 'Incorrect card digits provided.']);
        exit;
    }

    $new_user = [
        'email' => $email,
        'name' => $charge['billing_details']['name'] ?? 'Restored User',
        'ip' => $current_ip,
        'last4' => $stripe_last4,
        'date' => date('Y-m-d H:i:s')
    ];
    
    // Update local cache
    $updated = false;
    foreach ($data as $key => $user) {
        if (isset($user['email']) && strtolower(trim($user['email'])) === strtolower(trim($email))) {
            $data[$key] = $new_user;
            $updated = true;
            break;
        }
    }
    
    if (!$updated) {
        $data[] = $new_user;
    }
    
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => "We couldn't find a record of purchase for this email."]);
}
?>
